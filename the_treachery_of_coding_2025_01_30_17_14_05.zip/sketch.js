let img;
let myFont;

function preload() {

  img = loadImage('/assets/Muybridge-onehalf.jpg');
  myFont = loadFont('/assets/Parisienne-Regular.ttf');
}

function setup() {

  createCanvas(windowWidth, windowHeight);
  background(50);
  image(img, 0, 0, width, height, 0, 0, img.width, img.height, CONTAIN);
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

function draw() { 
  fill('goldenrod'); 
  textFont(myFont,'32');
  textAlign(CENTER, BOTTOM);
  text("Ceci n'est pas une animation",
       windowWidth / 2,
       windowHeight - 50);
}